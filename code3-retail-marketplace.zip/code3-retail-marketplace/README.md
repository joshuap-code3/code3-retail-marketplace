# Code3 Retail Marketplace

Internal Claude plugin marketplace for the Code3 retail media team.

## Plugins
- **code3-retail-optimizer** — drop in any ad-platform data dump; it classifies the
  report, routes to the right analysis skill, and benchmarks against client goals
  from the intake sheet.

## Add this marketplace
**Claude Code (CLI):**
```
/plugin marketplace add code3/code3-retail-marketplace
/plugin install code3-retail-optimizer@code3-retail-marketplace
```
**Cowork (desktop app):** Settings → Capabilities → add marketplace by repo URL,
then install code3-retail-optimizer.

## Update after pushing changes
Bump the version in `code3-retail-optimizer/.claude-plugin/plugin.json`, push, then
users run `/plugin marketplace update code3-retail-marketplace` (or Refresh in
Settings → Capabilities).
